﻿using Questor.Questao2.Library.Domain.Entities;

namespace Questor.Questao2.Library.Domain.Interfaces
{
    public interface ILancamentoRepository : IBaseRepository<Lancamentos>
    {
    }
}
