﻿using Questor.Questao2.Library.Domain.Entities;

namespace Questor.Questao2.Library.Domain.Interfaces
{
    public interface ICategoriaRepository : IBaseRepository<Categoria>
    {
    }
}
