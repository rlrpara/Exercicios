﻿namespace Questor.Questao2.Library.Domain.Entities
{
    public class ProdutoView
    {
        public int ProdutoId { get; set; }
        public string ProdutoNome { get; set; }

        public int QuantidadeCliente { get; set; }
  
    }
}
